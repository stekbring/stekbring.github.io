import tkinter as tk
from tkinter import ttk
from PIL import ImageGrab
import io
import win32clipboard
import pyautogui
import time
import pyperclip
import json
import tkinter.simpledialog as simpledialog
import os
from PIL import Image
import mss
import sys
from screeninfo import get_monitors


root = tk.Tk()
root.title("AC Help v2.2")
root.geometry("1155x290+1685+646")
root.attributes("-topmost", True)
auto_paste = tk.BooleanVar(value=False)

location_profile = "test"  # Standardprofil

# Konfigurera knappar i flik 1
button_width = 10
button_height = 2
font_size = ("Segoe UI", 12)
font_size2 = ("Segoe UI", 12)
font_size3 = ("Segoe UI", 13)
font_size4 = ("Segoe UI", 14)

def resource_path(relative_path):
    """ Hämta absolut sökväg till resurs för både utveckling och PyInstaller .exe """
    try:
        base_path = sys._MEIPASS  # När det körs som .exe
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


# Ladda in textdata från fil
with open(resource_path("texts.json"), "r", encoding="utf-8") as f:
    text_dict = json.load(f)


def get_auto_paste_position():
    coords_data = load_coords()
    pos = coords_data.get(location_profile, {}).get("auto_paste_position", None)
    return pos  # Kan vara None om ej satt

# Exempel modifiering i paste_text:
def paste_text(code):
    x, y = pyautogui.position()
    text = text_dict.get(str(code), None)
    if not text:
        return
    pos = get_auto_paste_position()
    if auto_paste.get() and pos:
        pyautogui.click(pos[0], pos[1])
        pyautogui.moveTo(x, y)
        for _ in range(8):
            pyautogui.press('down')
            time.sleep(0.0)
        pyautogui.write(text, interval=0.01)
        pyautogui.hotkey('enter')
    else:
        pyperclip.copy(text)

def paste_image():
    x, y = pyautogui.position()
    pos = get_auto_paste_position()
    if auto_paste.get() and pos:
        pyautogui.click(pos[0], pos[1])
        pyautogui.moveTo(x, y)
        for _ in range(3):
            pyautogui.press('down')
            time.sleep(0.05)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(0.05)
        pyautogui.hotkey('enter')

        
    # Om auto_paste är av: bara kopiera bilden till urklipp, ingen klistra in


def update_current_coords():
    global hour_cords, graph_cords, table_cords
    coords_data = load_coords()
    current_coords = coords_data.get(location_profile, {})
    hour_cords = tuple(current_coords.get("hours", (0, 0, 0, 0)))
    graph_cords = tuple(current_coords.get("graph", (0, 0, 0, 0)))
    table_cords = tuple(current_coords.get("table", (0, 0, 0, 0)))

import mss

def copy_fixed_area_to_clipboard(zone):
    if zone == "hours":
        bbox = hour_cords
    elif zone == "graph":
        bbox = graph_cords
    elif zone == "table":
        bbox = table_cords

    with mss.mss() as sct:
        monitor = {"top": bbox[1], "left": bbox[0], "width": bbox[2] - bbox[0], "height": bbox[3] - bbox[1]}
        screenshot = sct.grab(monitor)
        img = Image.frombytes("RGB", screenshot.size, screenshot.rgb)

        output = io.BytesIO()
        img.convert("RGB").save(output, "BMP")
        data = output.getvalue()[14:]
        output.close()

        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32clipboard.CF_DIB, data)
        win32clipboard.CloseClipboard()

    paste_image()


def toggle_autopaste():
    state = "PÅ" if auto_paste.get() else "AV"

coords_file = resource_path("coords.json")

def load_coords():
    try:
        with open(coords_file, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

import tkinter as tk
from screeninfo import get_monitors

import tkinter as tk
from screeninfo import get_monitors

import tkinter as tk
from screeninfo import get_monitors

def wait_for_click():
    overlay = tk.Toplevel(root)
    overlay.attributes("-topmost", True)
    overlay.attributes("-alpha", 0.01)  # Nästan osynlig
    overlay.overrideredirect(True)
    overlay.config(cursor="tcross")

    # Hämta skärmdata
    monitors = get_monitors()
    min_x = min(m.x for m in monitors)
    min_y = min(m.y for m in monitors)
    max_x = max(m.x + m.width for m in monitors)
    max_y = max(m.y + m.height for m in monitors)
    total_width = max_x - min_x
    total_height = max_y - min_y

    # Sätt fönsterstorlek och placering
    overlay.geometry(f"{total_width}x{total_height}+{min_x}+{min_y}")
    overlay.update()
    overlay.focus_force()

    def on_click(event):
        x, y = event.x_root, event.y_root
        print(f"Position sparad: ({x}, {y})")
        coords_data = load_coords()
        if location_profile not in coords_data:
            coords_data[location_profile] = {}
        coords_data[location_profile]["auto_paste_position"] = (x, y)
        save_coords(coords_data)
        overlay.destroy()

    def on_escape(event):
        print("Val av position avbröts.")
        overlay.destroy()

    overlay.bind("<Button-1>", on_click)
    overlay.bind("<Escape>", on_escape)

    # Kör fönstret – men blockera inte resten av appen
    overlay.grab_set()
    root.wait_window(overlay)




def on_click_capture(event):
    x, y = event.x_root, event.y_root
    print(f"Position sparad: {(x, y)}")
    coords_data = load_coords()
    if location_profile not in coords_data:
        coords_data[location_profile] = {}
    coords_data[location_profile]["auto_paste_position"] = (x, y)
    save_coords(coords_data)
    root.config(cursor="")  # Återställ muspekare
    root.unbind("<Button-1>")

def save_coords(coords_data):
    with open(coords_file, "w") as f:
        json.dump(coords_data, f, indent=4)

def select_area_with_overlay_all_screens(zone_name):
    from PyQt5 import QtWidgets, QtGui, QtCore
    import sys

    class TransparentOverlay(QtWidgets.QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Transparent Selection Overlay")
            self.setWindowFlags(
                QtCore.Qt.WindowStaysOnTopHint |
                QtCore.Qt.FramelessWindowHint |
                QtCore.Qt.Tool
            )
            self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
            self.setCursor(QtCore.Qt.CrossCursor)

            # Beräkna total skärmstorlek över flera skärmar
            monitors = get_monitors()
            min_x = min(m.x for m in monitors)
            min_y = min(m.y for m in monitors)
            max_x = max(m.x + m.width for m in monitors)
            max_y = max(m.y + m.height for m in monitors)
            self.min_x = min_x
            self.min_y = min_y

            self.setGeometry(min_x, min_y, max_x - min_x, max_y - min_y)

            self.start = None
            self.end = None

        def paintEvent(self, event):
            painter = QtGui.QPainter(self)
            painter.setRenderHint(QtGui.QPainter.Antialiasing)

            if self.start and self.end:
                selection_rect = QtCore.QRect(self.start, self.end).normalized()

                # Skapa "hål i overlay"
                path = QtGui.QPainterPath()
                path.setFillRule(QtCore.Qt.OddEvenFill)
                path.addRect(QtCore.QRectF(self.rect()))  # hela skärmen
                path.addRect(QtCore.QRectF(selection_rect))  # hålet

                # Rita svart overlay med hål
                painter.fillPath(path, QtGui.QColor(0, 0, 0, 180))

                # Rita vit ram runt hålet
                pen = QtGui.QPen(QtGui.QColor(255, 255, 255), 2)
                painter.setPen(pen)
                painter.setBrush(QtCore.Qt.NoBrush)
                painter.drawRect(selection_rect)
            else:
                # Om inget markerat ännu: bara hel overlay
                painter.fillRect(self.rect(), QtGui.QColor(0, 0, 0, 180))


        def mousePressEvent(self, event):
            self.start = event.globalPos() - QtCore.QPoint(self.min_x, self.min_y)
            self.end = self.start
            self.update(QtCore.QRect(self.start, self.end).normalized().adjusted(-5, -5, 5, 5))

        def mouseMoveEvent(self, event):
            self.end = event.globalPos() - QtCore.QPoint(self.min_x, self.min_y)
            self.update(QtCore.QRect(self.start, self.end).normalized().adjusted(-50, -50, 50, 50))


        def mouseReleaseEvent(self, event):
            self.end = event.globalPos() - QtCore.QPoint(self.min_x, self.min_y)
            self.update(QtCore.QRect(self.start, self.end).normalized().adjusted(-5, -5, 5, 5))

            rect = QtCore.QRect(self.start, self.end).normalized()
            x1 = rect.left() + self.min_x
            y1 = rect.top() + self.min_y
            x2 = rect.right() + self.min_x
            y2 = rect.bottom() + self.min_y
            bbox = (x1, y1, x2, y2)

            coords_data = load_coords()
            if location_profile not in coords_data:
                coords_data[location_profile] = {}
            coords_data[location_profile][zone_name] = bbox
            save_coords(coords_data)
            update_current_coords()
            self.close()
            QtWidgets.QApplication.quit()


    app = QtWidgets.QApplication(sys.argv)
    overlay = TransparentOverlay()
    overlay.show()
    app.exec_()


def show_area_selection_popup():
    popup = tk.Toplevel(root)
    popup.title("Set Copy Area")
    popup.geometry("350x350+1200+351")
    popup.attributes("-topmost", True)
    popup.grab_set()

    label = tk.Label(popup, text="Choose area to copy from", font=("Segoe UI", 14))
    label.place(x=65, y=10)

    temp_selection = {}  # Temporär lagring

    def select_zone(zone):
        select_area_with_overlay_all_screens(zone)
        # Ladda in markerade värden från fil och uppdatera temporär lagring
        coords_data = load_coords()
        coords = coords_data.get(location_profile, {}).get(zone, None)
        if coords:
            temp_selection[zone] = coords
            status_label.config(text=f"{zone.capitalize()} area saved!")

    def save_selection():
        coords_data = load_coords()
        if location_profile not in coords_data:
            coords_data[location_profile] = {}

        for zone, coords in temp_selection.items():
            coords_data[location_profile][zone] = coords

        save_coords(coords_data)
        update_current_coords()
        print(f"Area Saved")
        popup.destroy()

    def configure_auto_paste():
        wait_for_click()
        popup.destroy()

    # Knappar
    btn_hours = tk.Button(popup, text="Hours", width=15, font=font_size4, command=lambda: select_zone("hours"))
    btn_graph = tk.Button(popup, text="Graph", width=15, font=font_size4, command=lambda: select_zone("graph"))
    btn_table = tk.Button(popup, text="Table", width=15, font=font_size4, command=lambda: select_zone("table"))
    btn_auto = tk.Button(popup, text="Configure Auto-paste", width=20, font=("Segoe UI", 10), command=configure_auto_paste)
    btn_save = tk.Button(popup, text="close", width=15, font=font_size, command=lambda: popup.destroy())

    status_label = tk.Label(popup, text="", font=("Segoe UI", 12), fg="green")

    # Placering
    btn_hours.place(x=95, y=50, width=160, height=40)
    btn_graph.place(x=95, y=100, width=160, height=40)
    btn_table.place(x=95, y=150, width=160, height=40)
    btn_auto.place(x=95, y=210, width=160, height=30)

    status_label.place(x=75, y=260, width=200, height=25)

    btn_save.place(x=115, y=300, width=120, height=30)



coords_data = load_coords()
current_coords = coords_data.get(location_profile, {})
hour_cords = tuple(current_coords.get("hours", (0, 0, 0, 0)))
graph_cords = tuple(current_coords.get("graph", (0, 0, 0, 0)))
table_cords = tuple(current_coords.get("table", (0, 0, 0, 0)))

style = ttk.Style()
style.configure('TNotebook.Tab', font=('Segoe UI', 14))

# Notebook - flikhanterare
notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True, padx=10, pady=(10,0))

# Profilväljare (drop-down)
profile_var = tk.StringVar(value=location_profile)

def on_profile_change(event):
    global location_profile
    location_profile = profile_var.get()
    update_current_coords()
    print(f"Profil ändrad till: {location_profile}")

profile_menu = ttk.Combobox(root, textvariable=profile_var, values=["Jobb", "Hemma", "1 Screen", "test"], state="readonly", font=("Segoe UI", 10), width=10)
profile_menu.place(x=1040, y=10)  # Justera x/y efter fönstrets layout
profile_menu.bind("<<ComboboxSelected>>", on_profile_change)


# Frame för flik 1
tab1 = ttk.Frame(notebook)
notebook.add(tab1, text="   ART   ")

# Frame för flik 2
tab2 = ttk.Frame(notebook)
notebook.add(tab2, text="   WLO   ")
# label_wlo = tk.Label(tab2, text="Coming soon!", font=("Segoe UI", 20, "italic"))
# label_wlo.place(x=450, y=50)


# Knappar i flik 1
btn1_1 = tk.Button(tab1, text="MU% (1172)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("machine_usage"))
btn1_2 = tk.Button(tab1, text="ACB# (5010)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("carryback"))
btn1_3 = tk.Button(tab1, text="OC% (5000)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("overload"))
btn1_4 = tk.Button(tab1, text="HECT (632)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("engine_coolant_temp"))
btn1_5 = tk.Button(tab1, text="IT% (3073)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("idle_time_before_shutdown"))
btn1_6 = tk.Button(tab1, text="HEOT (651)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("engine_oil_temp"))
btn1_7 = tk.Button(tab1, text="LAFP (3003)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("low_air_filter"))
btn1_8 = tk.Button(tab1, text="WL (3054)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("water_level"))
btn1_9 = tk.Button(tab1, text="LD (631)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("difflock_use"))
btn1_10 = tk.Button(tab1, text="TOP (3016)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("transmission_oil"))
btn1_11 = tk.Button(tab1, text="SB (590-92)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("service_brake_cooling_oil"))
btn1_12 = tk.Button(tab1, text="BU% (646)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("brake_usage"))
btn1_13 = tk.Button(tab1, text="HVAC (3041)", width=button_width, height=button_height, font=font_size3, command=lambda: paste_text("HVAC"))
btn1_14 = tk.Button(tab1, text="", width=button_width, height=button_height, font=font_size3, command=lambda: print("olle är bäst"))


btn1_1.place(x=12.5, y=20, width=145, height=65)
btn1_2.place(x=172.5, y=20, width=145, height=65)
btn1_3.place(x=332.5, y=20, width=145, height=65)
btn1_4.place(x=492.5, y=20, width=145, height=65)
btn1_5.place(x=652.5, y=20, width=145, height=65)
btn1_6.place(x=812.5, y=20, width=145, height=65)
btn1_7.place(x=972.5, y=20, width=145, height=65)
btn1_8.place(x=12.5, y=100, width=145, height=65)
btn1_9.place(x=172.5, y=100, width=145, height=65)
btn1_10.place(x=332.5, y=100, width=145, height=65)
btn1_11.place(x=492.5, y=100, width=145, height=65)
btn1_12.place(x=652.5, y=100, width=145, height=65)
btn1_13.place(x=812.5, y=100, width=145, height=65)
btn1_14.place(x=972.5, y=100, width=145, height=65)

# Knappar i flik 2

btn2_1 = tk.Button(tab2, text="Machine utilization", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("machine_usage"))
btn2_2 = tk.Button(tab2, text="Machine overspeed", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("machine_overspeed"))
btn2_3 = tk.Button(tab2, text="Engine coolant temp", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("engine_coolant_temp"))
btn2_4 = tk.Button(tab2, text="Cooling fan speed", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("cooling_fan_speed"))
btn2_5 = tk.Button(tab2, text="Engine oil pressure", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("engine_oil_pressure"))
btn2_6 = tk.Button(tab2, text="Engine speed distribution", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("engine_speed_distribution"))
btn2_7 = tk.Button(tab2, text="Idle time before shutdown", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("idle_time_before_shutdown"))
btn2_8 = tk.Button(tab2, text="Low engine oil level at start", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("low_engine_oil_start"))
btn2_9 = tk.Button(tab2, text="Low air filter pressure", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("low_air_filter"))
btn2_10 = tk.Button(tab2, text="High/Low voltage", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("high_low_voltage"))
btn2_11 = tk.Button(tab2, text="Transmission oil temp", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("transmission_oil"))
btn2_12 = tk.Button(tab2, text="Gears, time, distribution", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("gears_time_dist"))
btn2_13 = tk.Button(tab2, text="Machine speed shifting", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("machine_speed_shifting"))
btn2_14 = tk.Button(tab2, text="Difflock usage", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("difflock_use_wlo"))
btn2_15 = tk.Button(tab2, text="Engine speed shifting", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("engine_speed_shifting"))
btn2_16 = tk.Button(tab2, text="APS selector usage", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("aps_selector_use"))
btn2_17 = tk.Button(tab2, text="Front/Rear axle temp", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("front_rear_axle_temp"))
btn2_18 = tk.Button(tab2, text="Parking brake abuse", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("parking_brake_abuse"))
btn2_19 = tk.Button(tab2, text="HVAC", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("HVAC"))
btn2_20 = tk.Button(tab2, text="Hydraulic oil temp", width=button_width, height=button_height, font=font_size2, command=lambda: paste_text("hydraulic_oil_temp"))

# Första raden (10 knappar på y=10)
# Rad 1
# Rad 1
# Rad 1
# Rad 1
# Rad 1
btn2_1.place(x=5, y=5, width=220, height=40)
btn2_2.place(x=230, y=5, width=220, height=40)
btn2_3.place(x=455, y=5, width=220, height=40)
btn2_4.place(x=680, y=5, width=220, height=40)
btn2_5.place(x=905, y=5, width=220, height=40)

# Rad 2
btn2_6.place(x=5, y=50, width=220, height=40)
btn2_7.place(x=230, y=50, width=220, height=40)
btn2_8.place(x=455, y=50, width=220, height=40)
btn2_9.place(x=680, y=50, width=220, height=40)
btn2_10.place(x=905, y=50, width=220, height=40)

# Rad 3
btn2_11.place(x=5, y=95, width=220, height=40)
btn2_12.place(x=230, y=95, width=220, height=40)
btn2_13.place(x=455, y=95, width=220, height=40)
btn2_14.place(x=680, y=95, width=220, height=40)
btn2_15.place(x=905, y=95, width=220, height=40)

# Rad 4
btn2_16.place(x=5, y=140, width=220, height=40)
btn2_17.place(x=230, y=140, width=220, height=40)
btn2_18.place(x=455, y=140, width=220, height=40)
btn2_19.place(x=680, y=140, width=220, height=40)
btn2_20.place(x=905, y=140, width=220, height=40)


# 👇 Längst ner – Auto Paste och Kopiera-knapp
bottom_frame = tk.Frame(root, height=50)
bottom_frame.pack(fill='x', padx=5, pady=5)

toggle_btn = tk.Checkbutton(
    bottom_frame, 
    text="🔁 Auto Paste", 
    variable=auto_paste, 
    onvalue=True, 
    offvalue=False, 
    font=font_size, 
    command=toggle_autopaste
)

copy_btn = tk.Button(bottom_frame, text="📸 Copy Analysis Hours", height=2, font=font_size, command=lambda:copy_fixed_area_to_clipboard("hours"))
copy_btn2 = tk.Button(bottom_frame, text="📊 Copy Graph", height=2, font=font_size, command=lambda:copy_fixed_area_to_clipboard("graph"))
copy_btn3 = tk.Button(bottom_frame, text="🔢 Copy Table", height=2, font=font_size, command=lambda:copy_fixed_area_to_clipboard("table"))
matris_btn = tk.Button(bottom_frame, text="No New Matris Reading", height=2, font=font_size, command=lambda:paste_text("no_new_matris"))
set_btn = tk.Button(bottom_frame, text="Set copy area", height=2, font=("Segoe UI", 10), command=show_area_selection_popup)

copy_btn.place(x=17.5, y=5, width=190, height=40)
copy_btn2.place(x=217.5, y=5, width=150, height=40)
copy_btn3.place(x=377.5, y=5, width=150, height=40)
matris_btn.place(x=537.5, y=5, width=190, height=40)
toggle_btn.place(x=807.5, y=0, width=180, height=50)
set_btn.place(x=1025, y=10, width=100, height=30)


update_current_coords()


root.mainloop()
